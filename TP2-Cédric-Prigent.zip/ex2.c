#include <sys/types.h>     /* key_t  */
#include <sys/ipc.h>       /* ftok   */
#include <sys/sem.h>       /* semget, semctl, semop */
#include <sys/stat.h>      /* stat, struct stat  */
#include <stdlib.h>        /* malloc */
#include <stdio.h>         /* perror, printf */
#include <errno.h>         /* errno */
#include <unistd.h>
#include <fcntl.h>

#define PRJVAL  1

struct sembuf tab[1];

int P(int semid, int noSem){
	int res;
	tab[0].sem_num = noSem;
	tab[0].sem_op = -1;
	res = semop(semid,tab,1);
	return res;
}

int V(int semid, int noSem){
	int res;
	tab[0].sem_num = noSem;
	tab[0].sem_op = +1;
	res = semop(semid,tab,1);
	return res;
}

int main(){
	int semid, proc, file;
	char c[256];
	key_t key = ftok("toto",PRJVAL);
	int nbLecteur = 0;
	semid = semget(key,1,0);
	if(semid==-1){
		printf("Erreur lors de la création du semaphore\n");
		return -1;
	}
	printf("%d\n",semid);
	proc=fork();
	switch(proc){
		case -1 :
			printf("Problème lors de la création du processus");
			break;
		case 0 : 			//lecteur
			P(semid,2);		//P(prioritéRedacteur)
			P(semid,1);		//P(lecteur)
			nbLecteur++;
			if(nbLecteur==1){
				P(semid,0);	//P(donne)
			}
			V(semid,2);		//V(prioritéRedacteur)
			V(semid,1);		//V(lecteur)
			file = open("donnee",O_RDWR,0755);
			read(file,c,20);
			P(semid,1);		//P(lecteur)
			nbLecteur--;
			if(nbLecteur==0){
				V(semid,0);	//V(donne)
			}
			V(semid,1); 	//V(lecteur)
			printf("processus fils terminé\n");
			semctl(semid,1,IPC_RMID);
			break;
		default : 			//redacteur
			P(semid,2);		//P(prioritéRedacteur)
			P(semid,0);		//P(donnee)
			file = open("donnee",O_RDWR,0755);
			write(file,"bonjour",7);
			V(semid,0);		//V(donne)
			V(semid,2);		//V(prioritéRedacteur)
			printf("Processus père terminé\n");
			semctl(semid,1,IPC_RMID);
	}

	return 0;
}

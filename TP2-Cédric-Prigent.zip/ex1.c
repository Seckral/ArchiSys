#include <sys/types.h>     /* key_t  */
#include <sys/ipc.h>       /* ftok   */
#include <sys/sem.h>       /* semget, semctl, semop */
#include <sys/stat.h>      /* stat, struct stat  */
#include <stdlib.h>        /* malloc */
#include <stdio.h>         /* perror, printf */
#include <errno.h>         /* errno */
#include <unistd.h>

#define PRJVAL  1

struct sembuf tab[1];

int P(int semid, int noSem){
	int res;
	tab[0].sem_num = noSem;
	tab[0].sem_op = -1;
	res = semop(semid,tab,1);
	return res;
}

int V(int semid, int noSem){
	int res;
	tab[0].sem_num = noSem;
	tab[0].sem_op = +1;
	res = semop(semid,tab,1);
	return res;
}


int main(){
	int semid, proc;
	key_t key = ftok("toto",PRJVAL);
	semid = semget(key,1,0);
	if(semid==-1){
		printf("Erreur lors de la création du semaphore\n");
		return -1;
	}
	printf("%d\n",semid);
	proc=fork();
	switch(proc){
		case -1 :
			printf("Problème lors de la création du processus");
			break;
		case 0 : 			//P2
			sleep(2);		//teste si P1 attend bien P2
			V(semid,0);
			P(semid,1);
			printf("processus fils terminé\n");
			semctl(semid,1,IPC_RMID);
			break;
		default : 			//P1
			V(semid,1);
			P(semid,0);
			printf("Processus père terminé\n");
			semctl(semid,1,IPC_RMID);
	}

	return 0;
}
